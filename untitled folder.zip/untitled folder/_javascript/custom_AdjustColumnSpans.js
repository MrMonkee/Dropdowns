


    <!-- Main Column Span Toggling Script -->


function AdjustColumnSpans() {
	
		
    if ($(window).width() < 991) {
		
		$('#PussCat1').removeClass('col-sm-3');
		$('#PussCat1').removeClass('col-sm-4');
		$('#PussCat1').addClass('col-sm-6');
		
		$('#PussCat2').removeClass('col-sm-3');
		$('#PussCat2').removeClass('col-sm-4');
		$('#PussCat2').addClass('col-sm-6');
		
		$('#PussCat3').removeClass('col-sm-3');
		$('#PussCat3').removeClass('col-sm-4');
		$('#PussCat3').addClass('col-sm-6');
		
		$('#PussCat4').removeClass('col-sm-3');
		$('#PussCat4').removeClass('col-sm-4');
		$('#PussCat4').addClass('col-sm-6');
		
    }

			else
	
	if ($(window).width() < 1199) {
		
		$('#PussCat1').removeClass('col-sm-3');
		$('#PussCat1').removeClass('col-sm-6');
		$('#PussCat1').addClass('col-sm-4');
		
		$('#PussCat2').removeClass('col-sm-3');
		$('#PussCat2').removeClass('col-sm-6');
		$('#PussCat2').addClass('col-sm-4');
		
		$('#PussCat3').removeClass('col-sm-3');
		$('#PussCat3').removeClass('col-sm-6');
		$('#PussCat3').addClass('col-sm-4');
		
		$('#PussCat4').removeClass('col-sm-3');
		$('#PussCat4').removeClass('col-sm-6');
		$('#PussCat4').addClass('col-sm-4');
		
    }
	
			else

	if ($(window).width() < 10000) {
		
		$('#PussCat1').removeClass('col-sm-4');
		$('#PussCat1').addClass('col-sm-3');
		
		$('#PussCat2').removeClass('col-sm-4');
		$('#PussCat2').addClass('col-sm-3');
		
		$('#PussCat3').removeClass('col-sm-4');
		$('#PussCat3').addClass('col-sm-3');
		
		$('#PussCat4').removeClass('col-sm-4');
		$('#PussCat4').addClass('col-sm-3');
		
    }
	
	
	
}

$(document).ready( function() {
    $(window).resize(AdjustColumnSpans);
    AdjustColumnSpans();
});

