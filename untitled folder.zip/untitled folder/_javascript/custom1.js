


 <!-- JS for toggling the Left Menu Bar -->
	
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
		  $("#IDcontainer-fluid").toggleClass("container-fluid-toggled");
    });
	
	
	
	
 <!-- JS for toggling the Logo state -->
	
function LogoLit(parm) {

      link = document.getElementById('IDLogoChanger' + parm)
      link.src = '_mainimages/LogoMiniLit1.png';
}

function LogoStatic(parm) {
	
      link = document.getElementById('IDLogoChanger' + parm)
      link.src = '_mainimages/LogoMini1.png';
}





 <!-- JS for preventing double-tap problem with dropdown menus on mobile only -->





 <!-- JS for determining which content is shown when mouse cursor is detected & which content is shown when finger-touch only is detected -->

;(function(){
	var isTouch = false //var to indicate current input type (is touch versus no touch) 
	var isTouchTimer 
	var curRootClass = '' //var indicating current document root class ("ClassFingerTouchOnly" or "")
	
	function addtouchclass(e){
		clearTimeout(isTouchTimer)
		isTouch = true
		if (curRootClass != 'ClassFingerTouchOnly'){ //add "ClassFingerTouchOnly' class if it's not already present
			curRootClass = 'ClassFingerTouchOnly'
			document.documentElement.classList.add(curRootClass)
		}
		isTouchTimer = setTimeout(function(){isTouch = false}, 500) //maintain "istouch" state for 500ms so removetouchclass doesn't get fired immediately following a touch event
	}
	
	function removetouchclass(e){
		if (!isTouch && curRootClass == 'ClassFingerTouchOnly'){ //remove 'ClassFingerTouchOnly' class if not triggered by a touch event and class is present
			isTouch = false
			curRootClass = ''
			document.documentElement.classList.remove('ClassFingerTouchOnly')
		}
	}
	
	document.addEventListener('touchstart', addtouchclass, false) //this event only gets called when input type is touch
	document.addEventListener('mouseover', removetouchclass, false) //this event gets called when input type is everything from touch to mouse/ trackpad
})();




  <!-- JS for determining the Main Page Content height and adjusting it -->


function htmlbodyHeightUpdate() {
		
		var height3 = $( window ).height()
		var height1 = $('.nav').height()+50
		height2 = $('.main').height()
		if(height2 > height3){
			$('html').height(Math.max(height1,height3,height2)+10);
			$('body').height(Math.max(height1,height3,height2)+10);
		}
		
		else
		
		{
			$('html').height(Math.max(height1,height3,height2));
			$('body').height(Math.max(height1,height3,height2));
		}
		
}
	
	$(document).ready(function () {
		htmlbodyHeightUpdate()
		$( window ).resize(function() {
			htmlbodyHeightUpdate()
		});
		$( window ).scroll(function() {
			height2 = $('.main').height()
  			htmlbodyHeightUpdate()
		});
	});
	
	








  <!-- JS for activating the Left Side Bar Dropdown Menu -->


/*jQuery(document).ready(function() {
	jQuery('.leftdropdownsetcontainer ul li ul').hide();
});

jQuery(document).click(function(event) {
	var clickover = $(event.target);

	if(jQuery(clickover).closest('.leftdropdownset-nav-side-menu').length == 0) {
		jQuery('.leftdropdownsetcontainer ul li ul').slideUp(50);
		jQuery('.leftdropdownsetcontainer ul li').removeClass('hover');
		jQuery('.leftdropdownsetcontainer ul li').removeClass('open');
	}
});

jQuery(document).on("click", '.leftdropdownsetcontainer ul li a', function(e) {
	
    var listItem = jQuery(this).closest('li');
	var subMenu = listItem.has('ul').length;
        if (!listItem.is('.hover') && subMenu > 0) {
			jQuery('.leftdropdownsetcontainer ul li ul').slideUp(50);
			jQuery('.leftdropdownsetcontainer ul li').removeClass('hover');
            // Opening drop-down logic here. e.g. adding 'open' class to <li>
            e.preventDefault();
            listItem.addClass('hover');
            listItem.children('ul').slideDown(50);
        } else if (listItem.is('.hover') && subMenu > 0) {
        	e.preventDefault();
        	listItem.removeClass('hover');
            listItem.children('ul').slideUp(50);
        }
});*/




